"""
Main entry point for voice-mcp when called as a module.
"""

from .cli import voice_mcp

if __name__ == "__main__":
    voice_mcp()